import { signInWithEmailAndPassword } from 'firebase/auth'
import { addDoc, collection, getDocs, getDoc, doc, updateDoc, setDoc, where, deleteDoc, serverTimestamp } from 'firebase/firestore'
import { getDownloadURL, ref, uploadBytes } from 'firebase/storage'
import { FIREBASE_AUTH, STORAGE_CONFIG, FIRESTORE_DB } from '../../firebaseConfig'
import En from '../data/locals/En'

const loginWithEmail = async (email, password, callBack) => {
  signInWithEmailAndPassword(FIREBASE_AUTH, email, password)
    .then(async data => {
      callBack(data)
    })
    .catch(error => {
      callBack()
      if (error.code === 'auth/invalid-credential') {
        alert(En.invalidCredentials)
      }
    })
}

const getCollectionData = async table => {
  let data = []

  let querySnapshot = await getDocs(collection(FIRESTORE_DB, table))
  querySnapshot.forEach(function (doc) {
    if (doc.exists) {
      data.push({ ...doc.data() })
    } else {
      console.log('No document found!')
    }
  })
  return data
}

const getCollectionDataWhere = async (table, key, value) => {
  try {
    const querySnapshot = await getDocs(collection(FIRESTORE_DB, table), where(key, '==', value))

    if (querySnapshot?.empty) {
      console.log('No documents found with', key, '=', value)
      return null
    }

    const data = []
    querySnapshot.forEach((doc) => {
      data.push({ id: doc.id, ...doc.data() })
    })

    return data
  } catch (error) {
    console.error('Error fetching document:', error)
    return null
  }
}

const getDocumentById = async (collectionName, documentId) => {
  try {
    const docRef = doc(FIRESTORE_DB, collectionName, documentId)
    const docSnapshot = await getDoc(docRef)

    if (docSnapshot.exists()) {
      return { id: docSnapshot?.id, ...docSnapshot?.data() }
    } else {
      console.log('No document found with ID:', documentId)
      return null
    }
  } catch (error) {
    console.error('Error fetching document:', error)
    return null
  }
}

const addDocument = async (coll, jsonObject) => {
  try {
    const docRef = await addDoc(collection(FIRESTORE_DB, coll), {
      ...jsonObject,
      documentId: null,
      createdAt: serverTimestamp(),
    })

    const documentId = docRef.id
    await updateDoc(docRef, { documentId })
    console.log('Document written with ID: ', documentId)
    return documentId
  } catch (e) {
    console.error('Error adding document: ', e)
    return null
  }
}

const deleteDocument = async (coll, documentId) => {
  try {
    return await deleteDoc(doc(FIRESTORE_DB, coll, documentId))
  } catch (e) {
    console.error('Error adding document: ', e)
    return null
  }
}

const saveData = async (coll, documentId, jsonObject) => {
  try {
    const docRef = doc(FIRESTORE_DB, coll, documentId)
    await setDoc(docRef, { ...jsonObject, capital: true, updatedAt: serverTimestamp(), }, { merge: true })
    return docRef.id
  } catch (e) {
    console.error('Error adding document: ', e)
    return null
  }
}

const uploadImage = async (imageUri, folder) => {
  try {
    const response = await fetch(imageUri)
    const blobFile = await response.blob()

    const storageRef = ref(STORAGE_CONFIG, `${folder}/` + new Date().toISOString())

    const result = await uploadBytes(storageRef, blobFile)
    const url = await getDownloadURL(result.ref)

    return url
  } catch (err) {
    console.error('Error uploading image:', err)
    throw err
  }
}

export { addDocument, loginWithEmail, uploadImage, getCollectionDataWhere, getDocumentById, getCollectionData, saveData, deleteDocument }

