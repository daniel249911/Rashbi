import { StyleSheet } from 'react-native'
import React, { memo } from 'react'
import { pickDocument } from '../../utils/Helper'
import { hp, wp, COLOR, TEXT_STYLE, commonStyles } from '../../data/StyleGuides'
import { Label, Pressable } from '../reusables'
import En from '../../data/locals/En'

const DocumentPicker = ({ value, onChange, style }) => {

    const handleFileManager = async () => {
        const document = await pickDocument()
        onChange(document)
    }

    return (
        <Pressable style={[styles.container, style]} onPress={() => handleFileManager()}>
            <Label style={{ fontSize: 17, color: COLOR.black }}>{value.name ? value?.name : En.uploadPDF}</Label>
        </Pressable>
    )
}

export default memo(DocumentPicker)

const styles = StyleSheet.create({
    container: {
        height: hp(35),
        width: wp(30),
        backgroundColor: COLOR.white,
        borderRadius: hp(1.8),
        marginVertical: hp(1),
        ...commonStyles.center,
        ...commonStyles.shadow_3,
        borderWidth: 1,
        borderColor: COLOR.secondary,
    },
    input: {
        flex: 1,
        ...TEXT_STYLE.text,
        textAlign: 'right',
        marginRight: wp(1)
    },
    imageStyle: {
        height: '100%',
        width: '100%',
        borderRadius: hp(1.8),
    },
})