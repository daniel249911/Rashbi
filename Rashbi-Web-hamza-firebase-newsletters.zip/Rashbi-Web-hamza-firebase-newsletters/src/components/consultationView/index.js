import ConsultationView from './ConsultationView'
export default ConsultationView