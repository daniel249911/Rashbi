import { Image, StyleSheet } from 'react-native'
import React, { memo } from 'react'
import { hp, wp, commonStyles, COLOR } from '../../data/StyleGuides'
import { Label, Pressable } from '../reusables'

const SliderImage = ({ image, onPress, onRemovePress }) => {
    return (
        <Pressable style={styles.sliderView} onPress={() => onPress()}>
            <Pressable style={styles.removeButton} onPress={onRemovePress}>
                <Label style={styles.minusText}>{'-'}</Label>
            </Pressable>
            <Image source={image} style={styles.imageStyle} />
        </Pressable>
    )
}

export default memo(SliderImage)

const styles = StyleSheet.create({
    sliderView: {
        height: hp(9),
        width: wp(7.5),
        borderRadius: hp(2),
        borderWidth: hp(0.1),
        borderColor: COLOR.grey,
        ...commonStyles.center,
        marginVertical: hp(1),
        marginHorizontal: wp(1),
        ...commonStyles.shadow_3,
    },
    imageStyle: {
        height: '100%',
        width: '100%',
        borderRadius: hp(2),
    },
    removeButton: {
        height: hp(3.5),
        width: hp(3.5),
        ...commonStyles.center,
        borderRadius: hp(3),
        position: 'absolute',
        top: -hp(1.5),
        left: -hp(1.5),
        zIndex: 1,
        backgroundColor: COLOR.lightRed,
    },
    minusText: {
        fontSize: 30,
        color: COLOR.white,
        marginBottom: '14%',
    },
})