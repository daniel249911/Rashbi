import SideSlider from './SideSlider'
export default SideSlider