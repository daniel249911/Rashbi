import { StyleSheet, Picker } from 'react-native-web'
import React, { memo } from 'react'
import { COLOR, TEXT_STYLE, commonStyles, hp, wp } from '../../../data/StyleGuides'

const DropDown = ({ data, value, onChange, style }) => {
    return (
        <Picker
            selectedValue={value}
            onValueChange={onChange}
            style={[styles.container, style]}
        >
            {data?.map((item, index) => (
                <Picker.Item
                    key={index}
                    label={item?.label}
                    value={item?.value}
                />
            ))}
        </Picker>
    )
}

export default memo(DropDown)

const styles = StyleSheet.create({
    container: {
        height: hp(6.6),
        width: wp(25),
        borderRadius: hp(1.8),
        marginVertical: hp(1),
        backgroundColor: COLOR.white,
        ...commonStyles.horizontalView,
        ...commonStyles.shadow_3,
        borderWidth: 1,
        borderColor: COLOR.secondary,
        overflow: 'hidden',
        paddingHorizontal: wp(1),
        ...TEXT_STYLE.text,
        outlineColor: 'rgba(0,0,0,0)', outlineOffset: 0, outlineStyle: 'none',
        outlineWidth: 0, backgroundColor: COLOR.white,
    },
})
