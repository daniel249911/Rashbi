import React, { memo } from 'react'
import Pressable from '../pressable'
import If from '../if'
import { hp } from '../../../data/StyleGuides'

const SvgItem = (props) => {
    const { name, size = hp(3), style, onPress, buttonStyle } = props
    const Tag = name
    return (
        <If condition={name}>
            <If condition={onPress}
                elseComp={
                    <Tag size={size} height={size} width={size} style={style} />
                }
            >
                <Pressable style={buttonStyle} onPress={() => { onPress && onPress() }}>
                    <Tag size={size} height={size} width={size} style={style} />
                </Pressable>
            </If>
        </If>
    )
}

export default memo(SvgItem)