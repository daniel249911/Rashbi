import { Image, StyleSheet, TouchableOpacity, View } from 'react-native'
import React, { memo, useRef } from 'react'
import {
    Menu,
    MenuOptions,
    MenuTrigger,
} from 'react-native-popup-menu'
import { IMAGES } from '../../assets/images'
import { COLOR, hp, wp } from '../../data/StyleGuides'
import { Label, Pressable } from '../reusables'

const PopupModal = ({ data, firstHeading, secondHeading, thirdHeading, onFirstPress, onSecondPress, onThirdPress }) => {
    const menuRef = useRef(null)

    const handleImagePress = () => {
        if (menuRef.current) {
            menuRef.current.open()
        }
    }

    const handleHeadingPress = (callBack) => {
        callBack && callBack()
        menuRef.current.close()
    }

    return (
        <View>
            <TouchableOpacity activeOpacity={1} onPress={handleImagePress}>
                <Image resizeMode='contain' source={IMAGES.ThreeDot} style={{ height: hp(1.8), width: wp(0.5) }} />
            </TouchableOpacity>
            <Menu ref={menuRef}>
                <MenuTrigger />
                <MenuOptions optionsContainerStyle={{ backgroundColor: COLOR.secondary, borderRadius: hp(2) }}>
                    <View style={{ paddingHorizontal: hp(2), paddingVertical: hp(1) }}>

                        {firstHeading &&
                            <Pressable onPress={() => handleHeadingPress(onFirstPress)}>
                                <Label style={styles.text}>{firstHeading}</Label>

                            </Pressable>
                        }
                        {secondHeading &&
                            <Pressable onPress={() => handleHeadingPress(onSecondPress)}>
                                <Label style={styles.text}>{secondHeading}</Label>
                            </Pressable>

                        }
                        {thirdHeading &&
                            <Pressable onPress={() => handleHeadingPress(onThirdPress)}>
                                <Label style={styles.text}>{thirdHeading}</Label>
                            </Pressable>
                        }

                    </View>

                    {/* <MenuOption onSelect={() => alert(`Not called`)} disabled={true} text='Disabled' /> */}
                </MenuOptions>
            </Menu>
        </View>
    )
}

export default memo(PopupModal)

const styles = StyleSheet.create({
    text: {
        paddingVertical: hp(1), fontWeight: '600',
    },
})