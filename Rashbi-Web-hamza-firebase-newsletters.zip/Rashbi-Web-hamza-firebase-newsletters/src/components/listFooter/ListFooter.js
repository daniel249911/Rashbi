import { StyleSheet, View, Image } from 'react-native'
import React, { memo } from 'react'
import { Label, Pressable } from '../reusables'
import { IMAGES } from '../../assets/images'
import { COLOR, hp, wp, commonStyles } from '../../data/StyleGuides'

const ListFooter = ({ showPreviousButton, moveToNextPage, note, moveToPreviousPage, currentPage, showNextButton }) => {
    return (
        <View style={styles.container}>

            <Label style={styles.textStyle}>{note}</Label>

            <View style={styles.buttonContainer}>
                <Pressable
                    style={[styles.arrowButtons, showPreviousButton && { backgroundColor: COLOR.lightGrey_2 }]}
                    onPress={moveToPreviousPage}
                >
                    <Image source={IMAGES.LeftArrow} resizeMode='contain' style={styles.arrowStyle} />
                </Pressable>

                <Label style={styles.countStyle}>{currentPage}</Label>

                <Pressable
                    style={[styles.arrowButtons, showNextButton && { backgroundColor: COLOR.lightGrey_2 }]}
                    onPress={moveToNextPage}
                >
                    <Image
                        source={IMAGES.RightArrow}
                        resizeMode='contain'
                        style={styles.arrowStyle}
                    />
                </Pressable>
            </View>
        </View>
    )
}

export default memo(ListFooter)

const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        justifyContent: 'space-between',
        flexDirection: 'row-reverse',
        // backgroundColor: 'lightblue',
        paddingHorizontal: '5%',
        marginBottom: hp(3),
    },

    arrowButtons: {
        height: hp(5),
        width: hp(5),
        borderRadius: hp(3),
        backgroundColor: COLOR.secondary,
        ...commonStyles.center,
    },
    arrowStyle: {
        height: hp(1.9),
        width: hp(1.9),
    },
    buttonContainer: {
        ...commonStyles.horizontalView,
    },
    textStyle: {
        fontWeight: '500',
    },
    countStyle: {
        fontWeight: '700',
        paddingHorizontal: wp(1),
    },
})