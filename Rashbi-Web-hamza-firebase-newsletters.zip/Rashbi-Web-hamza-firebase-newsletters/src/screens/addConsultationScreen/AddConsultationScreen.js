import { ScrollView, StyleSheet, View } from 'react-native-web'
import React, { useState } from 'react'
import { Button, DropDown, If, ImagePicker, Input, Label, Layout, VideoPicker } from '../../components'
import En from '../../data/locals/En'
import { hp, wp, commonStyles, COLOR } from '../../data/StyleGuides'
import { IMAGES } from '../../assets/images'
import { handleResetStack } from '../../utils/Helper'
import { FIREBASE_STORAGE, FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import { addDocument, saveData, uploadImage } from '../../services/firebaseServices'
import { consultationTypes, consultations } from '../../data/DummyData'

const AddConsultationScreen = ({ navigation, route }) => {
    const params = route?.params
    const paramData = route?.params?.data
    const [image, setImage] = useState(paramData?.image || '')
    const [text, setText] = useState(paramData?.content || '')
    const [amount, setAmount] = useState(paramData?.amount || '0')
    const [fileName, setFileName] = useState(paramData?.fileName || '')
    const [fileType, setFileType] = useState(paramData?.fileType || consultationTypes.FREE)
    const [loading, setLoading] = useState(false)
    const [video, setVideo] = useState(paramData?.video || '')

    const handleAddConsultation = async () => {
        if (image && text && fileName && fileType && amount) {
            setLoading(true)
            let imageUrl = image

            if (!imageUrl?.includes('https:') && !imageUrl?.includes('http:')) {
                imageUrl = await uploadImage(image, FIREBASE_STORAGE.CONSULTATION)
                if (imageUrl === 'false') {
                    alert(En.somethingWentWrong)
                    return
                }
            }

            let finalAmount = amount
            if (fileType === consultationTypes.FREE) {
                finalAmount = 0
            }

            let formattedData = {
                image: imageUrl,
                content: text,
                fileType,
                fileName,
                amount: finalAmount,
            }

            if (video) {
                let videoUrl = video
                if (!videoUrl?.includes('https:') && !videoUrl?.includes('http:')) {
                    videoUrl = await uploadImage(video, FIREBASE_STORAGE.CONSULTATION_VIDEOS)
                    if (videoUrl === 'false') {
                        alert(En.somethingWentWrong)
                        return
                    }
                }
                formattedData.video = videoUrl
            }

            if (params?.isEdit) {
                await saveData(FIREBASE_COLLECTION.CONSULTATION, paramData?.documentId, formattedData)
            } else {
                await addDocument(FIREBASE_COLLECTION.CONSULTATION, formattedData)
            }
            setLoading(false)
            resetData()
        } else {
            alert(En.fillDataError)
        }
    }

    const resetData = () => {
        handleResetStack(navigation, SCREEN.CONSULTATION)
    }

    return (
        <Layout title={En.consultation}>
            <ScrollView
                showsVerticalScrollIndicator={false}
                overScrollMode='never'
                bounces={false}
            >
                <Label style={styles.fileText}>{En.fileForm}</Label>

                <View style={styles.mainContent}>

                    <View style={styles.horizontalView}>
                        <Label style={styles.inputHeading}>{En.file}:</Label>
                        <Input
                            multiline
                            value={text}
                            onChange={setText}
                            style={styles.multiInputStyle}
                        />
                    </View>

                    <View style={styles.inputContainer}>
                        <View style={styles.horizontalView}>
                            <Label style={styles.inputHeading}>{En.fileType}:</Label>
                            <DropDown
                                value={fileType}
                                onChange={setFileType}
                                data={consultations}
                            />
                        </View>
                        <View style={styles.horizontalView}>
                            <Label style={styles.inputHeading}>{En.fileName}</Label>
                            <Input
                                style={styles.halfInput}
                                value={fileName}
                                onChange={setFileName}
                            />
                        </View>
                        <If condition={fileType === consultationTypes.PAID}>
                            <View style={styles.horizontalView}>
                                <Label style={styles.inputHeading}>{En.amount}</Label>
                                <Input
                                    style={styles.halfInput}
                                    value={amount}
                                    onChange={setAmount}
                                />
                            </View>
                        </If>
                    </View>

                    <View style={styles.pickerContainer}>
                        <Label style={styles.inputHeading}>{En.selectVideo}</Label>
                        <ImagePicker
                            style={styles.imagePickerStyle}
                            value={image}
                            onChange={setImage}
                            text={`+ ${En.addImage}`}
                        />
                    </View>

                    <View style={styles.pickerContainer}>
                        <Label style={styles.inputHeading}>{En.addCover}</Label>
                        <VideoPicker value={video} onChange={setVideo} />
                    </View>


                    <View style={styles.buttonContainer}>
                        <Button
                            text={En.done}
                            style={styles.buttonStyle}
                            icon={IMAGES.TrueIcon}
                            isLoading={loading}
                            onPress={handleAddConsultation}
                        />
                        <Button
                            style={styles.buttonStyle}
                            text={En.cancel}
                            buttonColor={COLOR.white}
                            gradient={false}
                            onPress={() => resetData()}
                        />
                    </View>

                </View>
            </ScrollView>
        </Layout>
    )
}

export default AddConsultationScreen

const styles = StyleSheet.create({
    fileText: {
        paddingHorizontal: '3%',
        paddingVertical: '1%',
        marginBottom: hp(1.5),
        fontWeight: '700',
    },
    buttonStyle: {
        width: wp(10),
        ...commonStyles.center,
        height: hp(5)
    },
    horizontalView: {
        flexDirection: 'row-reverse',
        alignItems: 'flex-start',
    },
    mainContent: {
        flex: 1,
        paddingHorizontal: '5%',
    },
    multiInputStyle: {
        height: hp(18),
        width: wp(55),
    },
    inputHeading: {
        fontWeight: '600',
        fontSize: 16,
        marginHorizontal: wp(0.5),
        marginTop: hp(2.2),
    },
    inputContainer: {
        flexDirection: 'row-reverse',
        marginVertical: hp(1),
        alignSelf: 'flex-end',
        justifyContent: 'space-between',
    },
    halfInput: {
        width: wp(10),
    },
    imagePickerStyle: {
        height: hp(23),
        width: wp(18),
    },
    pickerContainer: {
        flexDirection: 'row-reverse',
        alignItems: 'flex-start',
        marginTop: hp(0.5),
    },
    buttonContainer: {
        ...commonStyles.justifyView,
        marginTop: hp(1),
        paddingHorizontal: '5%',
    },
})