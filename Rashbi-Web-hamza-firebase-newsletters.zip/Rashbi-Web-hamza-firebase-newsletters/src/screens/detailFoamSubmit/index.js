import DetailFoamSubmit from './DetailFoamSubmit'
export default DetailFoamSubmit