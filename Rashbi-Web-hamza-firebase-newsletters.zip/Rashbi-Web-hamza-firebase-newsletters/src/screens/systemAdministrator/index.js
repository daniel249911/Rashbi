import SystemAdministrator from './SystemAdministrator'
export default SystemAdministrator