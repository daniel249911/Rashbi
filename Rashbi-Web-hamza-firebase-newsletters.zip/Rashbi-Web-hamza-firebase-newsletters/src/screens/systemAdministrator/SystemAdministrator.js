import { StyleSheet, View } from 'react-native'
import React from 'react'
import { Label, Layout } from '../../components'

const SystemAdministrator = () => {
  return (
    <Layout>
      <View>
        <Label>CategoriesScreen</Label>
      </View>
    </Layout>
  )
}

export default SystemAdministrator

const styles = StyleSheet.create({})