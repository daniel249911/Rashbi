import { ScrollView, StyleSheet, View, ActivityIndicator } from 'react-native'
import React, { useState, useEffect } from 'react'
import { Button, CategoriesView, Input, Label, Layout, ListFooter } from '../../components'
import En from '../../data/locals/En'
import { hp, commonStyles, wp, COLOR } from '../../data/StyleGuides'
import { IMAGES } from '../../assets/images'
import { FIREBASE_COLLECTION, FIREBASE_DOCUMENT, SCREEN } from '../../data/enums'
import { usePagination, useSearch } from '../../utils/hooks'
import { getDocumentById, saveData } from '../../services/firebaseServices'
import { useIsFocused } from '@react-navigation/native'

const DetailFoamScreen = ({ navigation }) => {
    const [formData, setFormData] = useState([])
    const [loading, setLoading] = useState(false)
    const [formSearchResults, { search, handleSearch }] = useSearch(formData, 'fieldName')
    const isFocused = useIsFocused()

    const {
        renderData,
        currentPage,
        moveToNextPage,
        moveToPreviousPage,
        showPreviousButton,
        showNextButton,
        noteString,
    } = usePagination(formSearchResults)


    useEffect(() => {
        getFormData()
    }, [isFocused])

    const getFormData = async () => {
        setLoading(true)
        const data = await getDocumentById(FIREBASE_COLLECTION.APP_CONFIG, FIREBASE_DOCUMENT.DETAIL_FORM)
        if (data) {
            setFormData(data?.fields)
        }
        setLoading(false)
    }

    const getSerialNumber = (index) => {
        const entriesPerPage = 5
        return (currentPage - 1) * entriesPerPage + index + 1
    }

    const handleDeleteItem = async (id) => {
        const newArray = formData?.filter(x => x?.id !== id)
        const formattedData = { fields: newArray }
        await saveData(FIREBASE_COLLECTION.APP_CONFIG, FIREBASE_DOCUMENT.DETAIL_FORM, formattedData)
        getFormData()
    }

    return (
        <Layout title={En.detailForm}>

            <View style={styles.headerStyle}>

                <Button
                    text={En.addField}
                    icon={IMAGES.AddIcon}
                    style={styles.buttonStyle}
                    onPress={() => navigation.navigate(SCREEN.DETAIL_FOAM_SUBMIT)}
                />

                <View style={commonStyles.horizontalView}>
                    <Input
                        value={search}
                        onChange={handleSearch}
                        style={styles.inputContainer}
                    />
                    <Label style={{ fontWeight: '700' }}>{En.lookFor}</Label>
                </View>

            </View>

            <ScrollView
                bounces={false}
                overScrollMode='never'
                showsVerticalScrollIndicator={false}
            >
                <View style={styles.container}>
                    <Label style={{ fontWeight: '700' }}>{En.operations}</Label>
                    <Label style={{ fontWeight: '700' }}>{En.fieldName}</Label>
                    <Label style={{ fontWeight: '700' }}>.{En.serialNumber}</Label>
                </View>

                {loading ? <ActivityIndicator size={35} color={COLOR.red} style={{ marginTop: hp(2) }} />
                    :
                    renderData?.map((item, index) => (
                        <CategoriesView
                            text={item?.fieldName}
                            key={index}
                            number={getSerialNumber(index)}
                            firstHeading={En.edit}
                            secondHeading={En.delete}
                            onFirstPress={() => navigation.navigate(SCREEN.DETAIL_FOAM_SUBMIT)}
                            onSecondPress={() => handleDeleteItem(item?.id)}
                        />
                    ))}

            </ScrollView>


            <ListFooter
                note={noteString}
                showPreviousButton={showPreviousButton}
                moveToNextPage={moveToNextPage}
                moveToPreviousPage={moveToPreviousPage}
                currentPage={currentPage}
                showNextButton={showNextButton}
            />

            {/* <Label style={{ paddingHorizontal: '5%', fontWeight: '500' }}>{showingString}</Label>

            <View style={styles.buttonContainer}>
                <Pressable
                    style={[styles.arrowButtons, currentPage == 1 && { backgroundColor: COLOR.lightGrey_2 }]}
                    onPress={moveToPreviousPage}
                >
                    <Image source={IMAGES.LeftArrow} resizeMode='contain' style={styles.arrowStyle} />
                </Pressable>

                <Label style={{ fontWeight: '700', paddingHorizontal: '1%' }}>{currentPage}</Label>

                <Pressable
                    style={[styles.arrowButtons, currentPage == totalPages && { backgroundColor: COLOR.lightGrey_2 }]}
                    onPress={moveToNextPage}
                >
                    <Image source={IMAGES.RightArrow} resizeMode='contain' style={styles.arrowStyle} />
                </Pressable>
            </View> */}

        </Layout>
    )
}

export default DetailFoamScreen

const styles = StyleSheet.create({
    inputContainer: {
        width: wp('10%'),
        // backgroundColor: 'blue',
        borderRadius: hp(1),
        marginHorizontal: '1%',
        height: hp(5.7),
    },
    headerStyle: {
        ...commonStyles.justifyView,
        paddingHorizontal: '5%',
    },
    buttonStyle: {
        width: wp(18),
        ...commonStyles.center,
        height: hp(5)
    },
    container: {
        height: hp(6),
        width: '90%',
        marginHorizontal: '5%',
        backgroundColor: COLOR.secondary,
        borderRadius: hp(4),
        paddingHorizontal: '3%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        marginTop: '0.5%',
        alignItems: 'center',
        marginVertical: '1%',
    },
    arrowButtons: {
        height: hp(5),
        width: hp(5),
        borderRadius: hp(3),
        backgroundColor: COLOR.secondary,
        ...commonStyles.center,
    },
    arrowStyle: {
        height: '50%',
        width: '90%',
    },
    buttonContainer: {
        ...commonStyles.horizontalView,
        marginBottom: hp(3),
        marginLeft: '5%',
    },
})