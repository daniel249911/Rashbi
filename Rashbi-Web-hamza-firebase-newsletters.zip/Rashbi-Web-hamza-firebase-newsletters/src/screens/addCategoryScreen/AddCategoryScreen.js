import { StyleSheet, View } from 'react-native'
import React, { useState } from 'react'
import { Button, ImagePicker, Input, Label, Layout } from '../../components'
import { hp, wp, commonStyles, COLOR } from '../../data/StyleGuides'
import En from '../../data/locals/En'
import { addDocument, saveData, uploadImage } from '../../services/firebaseServices'
import { FIREBASE_STORAGE, FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import { handleResetStack } from '../../utils/Helper'

const AddCategoryScreen = ({ navigation, route }) => {
    const params = route?.params
    const paramData = route?.params?.data
    const [image, setImage] = useState(paramData?.image || '')
    const [name, setName] = useState(paramData?.title || '')
    const [loading, setLoading] = useState(false)

    const onDonePress = async () => {
        if (image && name) {
            setLoading(true)
            let imageUrl = image

            if (!imageUrl?.includes('https:') && !imageUrl?.includes('http:')) {
                imageUrl = await uploadImage(image, FIREBASE_STORAGE.CATEGORIES)
                if (imageUrl === 'false') {
                    alert(En.somethingWentWrong)
                    return
                }
            }

            const formattedData = {
                title: name,
                image: imageUrl,
            }

            if (params?.isEdit) {
                await saveData(FIREBASE_COLLECTION.CATEGORIES, paramData?.documentId, formattedData)
            } else {
                await addDocument(FIREBASE_COLLECTION.CATEGORIES, formattedData)
            }

            resetData()
        } else {
            alert(En.fillDataError)
        }
    }

    const resetData = () => {
        setLoading(false)
        handleResetStack(navigation, SCREEN.CATEGORIES)
    }

    return (
        <Layout title={En.addNewCategories}>
            <Label style={styles.headingText}>{En.categoryForm}</Label>
            <View style={{ flexDirection: 'row-reverse', alignItems: 'center' }}>
                <Label style={{ paddingHorizontal: '4%' }}>{En.categoryName}:</Label>
                <Input
                    value={name}
                    onChange={setName}
                    style={{ width: wp(30) }}
                />
            </View>
            <View style={{ flexDirection: 'row-reverse' }}>
                <Label style={{ paddingRight: '8%', paddingLeft: '4%' }}>{En.image}:</Label>
                <ImagePicker value={image} onChange={setImage} text={En.uploadImage} />
            </View>

            <View style={{ ...commonStyles.justifyView, paddingHorizontal: '5%', paddingTop: '2%' }}>
                <Button
                    text={En.done}
                    isLoading={loading}
                    style={styles.buttonStyle}
                    onPress={onDonePress}
                />
                <Button
                    text={En.cancel}
                    gradient={false}
                    buttonColor={COLOR.white}
                    style={styles.buttonStyle}
                />
            </View>
        </Layout>
    )
}

export default AddCategoryScreen

const styles = StyleSheet.create({
    headingText: {
        fontWeight: '600',
        paddingHorizontal: '4%',
        paddingVertical: '2%',
    },
    container: {
        width: wp(30),
        height: hp(40),
    },
    buttonStyle: {
        width: wp(10),
        ...commonStyles.center,
        height: hp(5),
    },
})