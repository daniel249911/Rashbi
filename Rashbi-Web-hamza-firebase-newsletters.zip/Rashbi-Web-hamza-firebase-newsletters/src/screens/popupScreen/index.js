import PopUpScreen from './PopUpScreen'
export default PopUpScreen