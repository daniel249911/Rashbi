import SubCategoriesScreen from './SubCategoriesScreen'
export default SubCategoriesScreen