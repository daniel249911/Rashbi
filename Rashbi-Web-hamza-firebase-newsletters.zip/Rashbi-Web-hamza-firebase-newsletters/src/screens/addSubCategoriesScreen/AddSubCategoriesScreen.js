import { StyleSheet, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import { Button, DropDown, ImagePicker, Input, Label, Layout } from '../../components'
import { hp, wp, commonStyles, COLOR } from '../../data/StyleGuides'
import { FIREBASE_STORAGE, FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import { IMAGES } from '../../assets/images'
import En from '../../data/locals/En'
import { addDocument, getCollectionData, saveData, uploadImage } from '../../services/firebaseServices'
import { handleResetStack } from '../../utils/Helper'

const AddSubCategoriesScreen = ({ navigation, route }) => {
    const params = route?.params
    const paramData = route?.params?.data
    const [image, setImage] = useState(paramData?.image || '')
    const [name, setName] = useState(paramData?.title || '')
    const [selectedCategory, setSelectedCategory] = useState(null)
    const [allCategories, setAllCategories] = useState([])
    const [loading, setLoading] = useState(false)

    useEffect(() => {
        getCategoriesData()
    }, [])

    const getCategoriesData = async () => {
        setLoading(true)
        const data = await getCollectionData(FIREBASE_COLLECTION.CATEGORIES)

        if (data) {
            const formattedData = data.map((x) => ({
                label: x?.title,
                value: x?.documentId,
            }))

            setAllCategories(formattedData)



            if (params?.isEdit) {
                const found = formattedData?.find(x => x?.value === paramData?.parentId)
                if (found) {
                    setSelectedCategory(found?.value)
                }
            } else {
                setSelectedCategory(formattedData[0]?.value)
            }
        }

        setLoading(false)
    }


    const onDonePress = async () => {
        if (image && name && selectedCategory) {

            setLoading(true)
            let imageUrl = image

            if (!imageUrl?.includes('https:') && !imageUrl?.includes('http:')) {
                imageUrl = await uploadImage(image, FIREBASE_STORAGE.SUB_CATEGORIES)
                if (imageUrl === 'false') {
                    alert(En.somethingWentWrong)
                    return
                }
            }

            const formattedData = {
                title: name,
                image: imageUrl,
                parentId: selectedCategory,
            }

            if (params?.isEdit) {
                await saveData(FIREBASE_COLLECTION.SUB_CATEGORIES, paramData?.documentId, formattedData)
            } else {
                await addDocument(FIREBASE_COLLECTION.SUB_CATEGORIES, formattedData)
            }

            resetData()
        } else {
            alert(En.fillDataError)
        }
    }

    const resetData = () => {
        setLoading(false)
        handleResetStack(navigation, SCREEN.SUB_CATEGORIES)
    }

    return (
        <Layout title={En.addNewSubCategory}>

            <Label style={styles.headingText}>{En.subCategoryForm}</Label>

            <View style={{ flexDirection: 'row-reverse', alignItems: 'center' }}>
                <Label style={{ paddingHorizontal: '2%' }}>{En.subCategoryName}:</Label>
                <Input
                    value={name}
                    onChange={setName}
                    style={{ width: wp(25) }}
                />
            </View>

            <View style={{ flexDirection: 'row-reverse', alignItems: 'center' }}>
                <Label style={{ paddingHorizontal: '4.2%' }}>{En.categoryName}:</Label>
                <DropDown
                    value={selectedCategory}
                    onChange={setSelectedCategory}
                    data={allCategories}
                />
            </View>

            <View style={{ flexDirection: 'row-reverse' }}>
                <Label style={{ paddingRight: '8%', paddingLeft: '4%' }}>{En.image}</Label>
                <ImagePicker value={image} onChange={setImage} text={En.uploadImage} />
            </View>

            <View style={styles.buttonContainer}>
                <Button
                    text={En.done}
                    isLoading={loading}
                    icon={IMAGES.TrueIcon}
                    style={styles.buttonStyle}
                    onPress={() => onDonePress()}
                />
                <Button
                    text={En.cancel}
                    gradient={false}
                    buttonColor={COLOR.white}
                    style={styles.buttonStyle}
                    onPress={() => resetData()}
                />
            </View>
        </Layout>
    )
}

export default AddSubCategoriesScreen

const styles = StyleSheet.create({
    headingText: {
        fontWeight: '600',
        paddingHorizontal: '4%',
        paddingVertical: '2%',
    },
    container: {
        width: wp(30),
        height: hp(40),
    },
    buttonStyle: {
        width: wp(10),
        ...commonStyles.center,
        height: hp(5),
    },
    imagePicker: {
        height: hp(10),
        width: wp(18),
    },
    buttonContainer: {
        ...commonStyles.justifyView,
        paddingHorizontal: '5%',
        paddingTop: '2%',
    },
})