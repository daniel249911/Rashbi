import { StyleSheet, View, ScrollView } from 'react-native'
import React, { useState } from 'react'
import { Button, DocumentPicker, DropDown, ImagePicker, Input, Label, Layout } from '../../components'
import { hp, wp, commonStyles, COLOR } from '../../data/StyleGuides'
import { FIREBASE_STORAGE, FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import { IMAGES } from '../../assets/images'
import En from '../../data/locals/En'
import { addDocument, saveData, uploadImage } from '../../services/firebaseServices'
import { handleResetStack } from '../../utils/Helper'
import { fileTypeData } from '../../data/DummyData'

const AddBookScreen = ({ navigation, route }) => {
  const params = route?.params
  const paramData = route?.params?.data
  const [name, setName] = useState(paramData?.title || '')
  const [image, setImage] = useState(paramData?.image || '')
  const [loading, setLoading] = useState(false)
  const [fileType, setFileType] = useState(paramData?.fileType || 'text')
  const [text, setText] = useState(paramData?.content || '')
  const [pdf, setPdf] = useState(paramData?.pdf ? { uri: paramData?.pdf, name: paramData?.pdfName } : {})

  const onPdfUpload = async () => {
    if (name && image && pdf) {
      setLoading(true)
      let documentUrl = pdf?.uri
      let imageUrl = image

      if (!documentUrl?.includes('https:') && !documentUrl?.includes('http:')) {
        documentUrl = await uploadImage(pdf?.uri, FIREBASE_STORAGE.BOOKS_PDF)
        if (documentUrl === 'false') {
          alert(En.somethingWentWrong)
          return
        }
      }

      if (!imageUrl?.includes('https:') && !imageUrl?.includes('http:')) {
        imageUrl = await uploadImage(image, FIREBASE_STORAGE.BOOKS)
        if (imageUrl === 'false') {
          alert(En.somethingWentWrong)
          return
        }
      }

      const formattedData = {
        title: name,
        image: imageUrl,
        pdf: documentUrl,
        pdfName: pdf?.name,
        fileType: fileType,
      }

      if (params?.isEdit) {
        await saveData(FIREBASE_COLLECTION.BOOKS, paramData?.documentId, formattedData)
      } else {
        await addDocument(FIREBASE_COLLECTION.BOOKS, formattedData)
      }

      resetData()
    } else {
      alert(En.fillDataError)
    }
  }

  const onTextUpload = async () => {
    if (name && image && text) {
      setLoading(true)
      let imageUrl = image

      if (!imageUrl?.includes('https:') && !imageUrl?.includes('http:')) {
        imageUrl = await uploadImage(image, FIREBASE_STORAGE.BOOKS)
        if (imageUrl === 'false') {
          alert(En.somethingWentWrong)
          return
        }
      }

      const formattedData = {
        title: name,
        image: imageUrl,
        content: text,
        fileType: fileType,
      }

      if (params?.isEdit) {
        await saveData(FIREBASE_COLLECTION.BOOKS, paramData?.documentId, formattedData)
      } else {
        await addDocument(FIREBASE_COLLECTION.BOOKS, formattedData)
      }

      resetData()
    } else {
      alert(En.fillDataError)
    }
  }

  const handleDonePress = () => {
    if (fileType === 'pdf') {
      onPdfUpload()
    } else {
      onTextUpload()
    }
  }

  const resetData = () => {
    setLoading(false)
    handleResetStack(navigation, SCREEN.BOOKS)
  }

  return (
    <Layout title={En.addNewBook}>
      <ScrollView
        bounces={false}
        overScrollMode='never'
        showsVerticalScrollIndicator={false}
      >

        <Label style={styles.headingText}>{En.bookForm}</Label>


        <View style={styles.reverseView}>
          <Label style={styles.heading}>{En.bookName}:</Label>
          <Input
            value={name}
            onChange={setName}
            style={{ width: wp(25) }}
          />
        </View>

        <View style={styles.reverseView}>
          <Label style={styles.heading}>{En.image}</Label>
          <ImagePicker value={image} onChange={setImage} text={En.uploadImage} />
        </View>

        <View style={styles.reverseView}>
          <Label style={styles.heading}>{En.fileType}:</Label>
          <DropDown
            value={fileType}
            onChange={setFileType}
            data={fileTypeData}
            style={styles.dropDown}
          />
        </View>


        {fileType == 'text' &&
          <View style={styles.reverseView}>
            <Label style={styles.heading}>{En.file}:</Label>
            <Input
              value={text}
              onChange={setText}
              multiline
              style={{ width: wp(50), height: hp(35) }}
            />
          </View>
        }

        {fileType == 'pdf' &&
          <View style={styles.reverseView}>
            <Label style={styles.heading}>{En.file}:</Label>
            <DocumentPicker value={pdf} onChange={setPdf} style={styles.documentStyle} />
          </View>
        }

        <View style={styles.buttonContainer}>
          <Button
            text={En.done}
            isLoading={loading}
            icon={IMAGES.TrueIcon}
            style={styles.buttonStyle}
            onPress={handleDonePress}
          />
          <Button
            text={En.cancel}
            gradient={false}
            buttonColor={COLOR.white}
            style={styles.buttonStyle}
            onPress={() => resetData()}
          />
        </View>

      </ScrollView>
    </Layout>
  )
}

export default AddBookScreen

const styles = StyleSheet.create({
  headingText: {
    fontWeight: '600',
    marginRight: wp(2),
    paddingVertical: '2%',
    textAlign: 'right',
  },
  heading: {
    width: wp(6.5),
    fontWeight: '600',
    marginRight: wp(3),
    textAlign: 'right',
    marginTop: hp(2),
  },
  reverseView: {
    flexDirection: 'row-reverse',
  },
  container: {
    width: wp(30),
    height: hp(40),
  },
  buttonStyle: {
    width: wp(10),
    ...commonStyles.center,
    height: hp(5),
  },
  imagePicker: {
    height: hp(10),
    width: wp(18),
  },
  buttonContainer: {
    ...commonStyles.justifyView,
    paddingHorizontal: wp(2),
    marginVertical: hp(2),
  },
  dropDown: {
    width: '10%',
    height: hp(6.6),
  },
  documentStyle: {
    alignSelf: 'flex-end',
    paddingHorizontal: '4%',
  },
})