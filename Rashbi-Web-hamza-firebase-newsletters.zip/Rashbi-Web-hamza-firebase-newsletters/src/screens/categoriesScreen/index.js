import CategoriesScreen from './CategoriesScreen'
export default CategoriesScreen