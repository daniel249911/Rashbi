import { StyleSheet, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import { Button, DocumentPicker, DropDown, Input, Label, Layout } from '../../components'
import { hp, wp, commonStyles, COLOR } from '../../data/StyleGuides'
import { FIREBASE_STORAGE, FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import En from '../../data/locals/En'
import { timeToReadData, fileTypeData } from '../../data/DummyData'
import { handleResetStack } from '../../utils/Helper'
import { addDocument, getDocumentById, saveData, uploadImage } from '../../services/firebaseServices'
import { serverTimestamp } from 'firebase/firestore'

const AddCategoryNote = ({ navigation, route }) => {
    const params = route?.params
    const paramData = route?.params?.data
    const [timeToRead, setTimeToRead] = useState(paramData?.timeToRead || timeToReadData[0]?.value)
    const [fileType, setFileType] = useState(paramData?.fileType || 'text')
    const [pdf, setPdf] = useState(paramData?.pdf ? { uri: paramData?.pdf, name: paramData?.pdfName } : {})
    const [text, setText] = useState(paramData?.content || '')
    const [loading, setLoading] = useState(false)

    // useEffect(() => {
    //     getExistingValues()
    // }, [])

    // const getExistingValues = async () => {
    //     const data = await getDocumentById(FIREBASE_COLLECTION.CATEGORY_CONTENT, paramData?.documentId)
    //     if (data) {
    //         if (data?.fileType === 'pdf') {
    //             setPdf({ name: data?.pdfName, uri: data?.pdf })
    //             setFileType(data?.fileType)
    //             setTimeToRead(data?.timeToRead)
    //         } else {
    //             setText(data?.content)
    //             setFileType(data?.fileType)
    //             setTimeToRead(data?.timeToRead)
    //         }
    //     }
    // }

    const onPdfUpload = async () => {
        if (pdf && timeToRead) {
            setLoading(true)
            let documentUrl = pdf?.uri

            if (!documentUrl?.includes('https:') && !documentUrl?.includes('http:')) {
                documentUrl = await uploadImage(pdf?.uri, FIREBASE_STORAGE.CATEGORY_CONTENT)
                if (documentUrl === 'false') {
                    alert(En.somethingWentWrong)
                    return
                }
            }

            const formattedData = {
                pdf: documentUrl,
                pdfName: pdf?.name,
                fileType,
                timeToRead,
                parentId: params?.parentId,
                updatedAt: serverTimestamp(),
            }
            if (params?.isEdit) {
                await saveData(FIREBASE_COLLECTION.CATEGORY_CONTENT, paramData?.documentId, formattedData)
            } else {
                await addDocument(FIREBASE_COLLECTION.CATEGORY_CONTENT, formattedData)
            }

            resetData()

        } else {
            alert(En.fillDataError)
        }
    }

    const resetData = () => {
        setLoading(false)
        handleResetStack(navigation, SCREEN.SUB_CATEGORIES)
    }

    const onTextUpload = async () => {
        if (text && timeToRead) {
            setLoading(true)
            const formattedData = {
                content: text,
                fileType,
                timeToRead,
                parentId: params?.parentId,
                updatedAt: serverTimestamp(),
            }

            if (params?.isEdit) {
                await saveData(FIREBASE_COLLECTION.CATEGORY_CONTENT, paramData?.documentId, formattedData)
            } else {
                await addDocument(FIREBASE_COLLECTION.CATEGORY_CONTENT, formattedData)
            }

            resetData()
        } else {
            alert(En.fillDataError)
        }
    }

    const handleDonePress = () => {
        if (fileType === 'pdf') {
            onPdfUpload()
        } else {
            onTextUpload()
        }
    }

    return (
        <Layout title={En.addNewContent}>
            <Label style={styles.headingText}>{En.subCategoryForm}</Label>

            <View style={{ flexDirection: 'row-reverse' }}>
                <Label style={{ paddingHorizontal: '4%' }}>{En.fileType}:</Label>
                <DropDown
                    value={fileType}
                    onChange={setFileType}
                    data={fileTypeData}
                    style={styles.dropDown}
                />
            </View>

            {fileType == 'text' &&
                <View style={{ flexDirection: 'row-reverse' }}>
                    <Label style={{ paddingHorizontal: '4%' }}>{En.file}:</Label>
                    <Input
                        value={text}
                        onChange={setText}
                        multiline
                        style={{ width: wp(50), height: hp(35) }}
                    />
                </View>
            }

            {fileType == 'pdf' &&
                <View style={{ flexDirection: 'row-reverse' }}>
                    <Label style={{ paddingHorizontal: '4%' }}>{En.file}:</Label>
                    <DocumentPicker value={pdf} onChange={setPdf} style={styles.documentStyle} />
                </View>
            }

            <View style={{ flexDirection: 'row-reverse', alignItems: 'center' }}>
                <Label style={{ paddingHorizontal: '4%' }}>{En.timeToRead}:</Label>
                <DropDown
                    value={timeToRead}
                    onChange={setTimeToRead}
                    data={timeToReadData}
                    style={styles.dropDown}
                />
            </View>

            {/* <View style={styles.footerButtons}>
                <Button
                    text={En.done}
                    style={styles.buttonStyle}
                    containerStyle={styles.button}
                // onPress={() => handlePickDocument()}
                />
                <Button
                    text={En.cancel}
                    style={styles.buttonStyle}
                    containerStyle={styles.button}
                />
            </View> */}

            <View style={styles.buttonContainer}>
                <Button
                    text={En.done}
                    style={styles.buttonStyle}
                    // icon={IMAGES.TrueIcon}
                    isLoading={loading}
                    onPress={handleDonePress}
                />
                <Button
                    style={styles.buttonStyle}
                    text={En.cancel}
                    buttonColor={COLOR.white}
                    gradient={false}
                    onPress={() => resetData()}
                />
            </View>

        </Layout>
    )
}

export default AddCategoryNote

const styles = StyleSheet.create({
    headingText: {
        fontWeight: '600',
        paddingHorizontal: '4%',
        paddingVertical: '2%',
    },
    container: {
        width: wp(30),
        height: hp(40),
    },
    buttonStyle: {
        height: hp(5),
        width: wp(10),
    },
    button: {
        marginHorizontal: '2%',
    },
    footerButtons: {
        ...commonStyles.horizontalView_m1,
        // justifyContent: 'center',
    },
    documentStyle: {
        alignSelf: 'flex-end',
        paddingHorizontal: '4%',
    },
    buttonContainer: {
        ...commonStyles.justifyView,
        paddingHorizontal: '5%',
        marginTop: '3%',
    },
    dropDown: {
        width: '10%',
        height: hp(5),
    },
})