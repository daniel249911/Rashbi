import NewsLettersScreen from './NewsLettersScreen'
export default NewsLettersScreen