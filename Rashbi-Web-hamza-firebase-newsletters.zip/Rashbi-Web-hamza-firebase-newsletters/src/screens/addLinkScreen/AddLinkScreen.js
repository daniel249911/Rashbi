import { StyleSheet, View } from 'react-native'
import React, { useState } from 'react'
import { Button, ImagePicker, Input, Label, Layout } from '../../components'
import { hp, wp, commonStyles, COLOR } from '../../data/StyleGuides'
import { FIREBASE_STORAGE, FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import En from '../../data/locals/En'
import { addDocument, saveData, uploadImage } from '../../services/firebaseServices'
import { handleResetStack } from '../../utils/Helper'

const AddLinkScreen = ({ navigation, route }) => {
    const params = route?.params
    const paramData = route?.params?.data
    const [image, setImage] = useState(paramData?.image || '')
    const [websiteAddress, setWebsiteAddress] = useState(paramData?.url || '')
    const [loading, setLoading] = useState(false)

    const handleDonePress = async () => {
        if (image && websiteAddress) {
            setLoading(true)

            let imageUrl = image

            if (!imageUrl?.includes('https:') && !imageUrl?.includes('http:')) {
                imageUrl = await uploadImage(image, FIREBASE_STORAGE.SOCIAL_LINKS)
                if (imageUrl === 'false') {
                    alert(En.somethingWentWrong)
                    return
                }
            }

            const formattedData = { image: imageUrl, url: websiteAddress }

            if (params?.isEdit) {
                await saveData(FIREBASE_COLLECTION.SOCIAL_LINKS, paramData?.documentId, formattedData)
            } else {
                await addDocument(FIREBASE_COLLECTION.SOCIAL_LINKS, formattedData)
            }

            resetData()
        } else {
            alert(En.fillDataError)
        }
    }

    const resetData = () => {
        setLoading(false)
        setImage('')
        setWebsiteAddress('')
        handleResetStack(navigation, SCREEN.LINK_DETAIL)
    }

    return (
        <Layout title={En.links}>
            <Label style={styles.headingText}>{En.socialLinkForm}</Label>

            <View style={styles.horizontalReverse}>
                <Label style={styles.headerStyle}>{`${En.websiteAddress}:`}</Label>
                <Input
                    style={{ width: wp(30) }}
                    value={websiteAddress}
                    onChange={setWebsiteAddress}
                />
            </View>

            <View style={styles.flexReverse}>
                <Label style={styles.headerStyle}>{`${En.addIcon}:`}</Label>
                <ImagePicker
                    value={image}
                    onChange={setImage}
                    text={`+ ${En.addImage}`}
                />
            </View>

            <View style={styles.buttonContainer}>
                <Button
                    text={En.done}
                    style={styles.buttonStyle}
                    isLoading={loading}
                    onPress={handleDonePress}
                />
                <Button
                    style={styles.buttonStyle}
                    text={En.cancel}
                    buttonColor={COLOR.white}
                    gradient={false}
                    onPress={resetData}
                />
            </View>
        </Layout>
    )
}

export default AddLinkScreen

const styles = StyleSheet.create({
    headingText: {
        fontWeight: '600',
        paddingHorizontal: '4%',
        paddingVertical: '2%',
    },
    container: {
        width: wp(30),
        height: hp(40),
    },
    horizontalReverse: {
        flexDirection: 'row-reverse', alignItems: 'center',
    },
    headerStyle: {
        paddingHorizontal: '4%',
    },
    flexReverse: {
        flexDirection: 'row-reverse',
    },
    buttonStyle: {
        width: wp(10),
        ...commonStyles.center,
        height: hp(5),
    },
    buttonContainer: {
        ...commonStyles.justifyView,
        paddingHorizontal: '5%',
        paddingTop: '2%',
    },
})