import { ScrollView, StyleSheet, View, ActivityIndicator } from 'react-native'
import React, { useEffect, useState } from 'react'
import { ConsultationView, Input, Label, Layout, ListFooter } from '../../components'
import En from '../../data/locals/En'
import { hp, commonStyles, wp, COLOR } from '../../data/StyleGuides'
import { FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import { deleteDocument, getCollectionData } from '../../services/firebaseServices'
import { useSearch, usePagination } from '../../utils/hooks'
import { useIsFocused } from '@react-navigation/native'

const RequestScreen = ({ navigation }) => {
    const [requests, setRequests] = useState([])
    const [loading, setLoading] = useState(false)
    const [requestData, { search, handleSearch }] = useSearch(requests, 'fileName')
    const isFocused = useIsFocused()

    const {
        renderData,
        currentPage,
        moveToNextPage,
        moveToPreviousPage,
        showPreviousButton,
        showNextButton,
        noteString,
    } = usePagination(requestData)

    useEffect(() => {
        getUserRequests()
    }, [isFocused])

    const getSerialNumber = (index) => {
        const entriesPerPage = 5
        return (currentPage - 1) * entriesPerPage + index + 1
    }

    const getUserRequests = async () => {
        setLoading(true)
        const data = await getCollectionData(FIREBASE_COLLECTION.REQUEST)
        if (data) {
            setRequests(data)
        }
        setLoading(false)
    }

    const onViewDetailPress = (item) => {
        navigation.navigate(SCREEN.DETAIL_REQUEST, { data: item })
    }

    const handleDeleteItem = (id) => {
        deleteDocument(FIREBASE_COLLECTION.REQUEST, id)
        getUserRequests()
    }

    return (
        <Layout title={En.requests}>

            <View style={styles.headerStyle}>
                <Input
                    value={search}
                    onChange={handleSearch}
                    style={styles.inputContainer}
                />
                <Label style={{ fontWeight: '700' }}>{En.lookFor}</Label>
            </View>

            <ScrollView
                bounces={false}
                overScrollMode='never'
                showsVerticalScrollIndicator={false}
            >
                <View style={styles.container}>
                    <Label style={[styles.headerText, { textAlign: 'left' }]}>{En.operations}</Label>
                    <Label style={[styles.headerText, { width: '37%' }]}>{En.fileType}</Label>
                    <Label style={[styles.headerText, { width: '42%' }]}>{En.files}</Label>
                    <Label style={[styles.headerText, { textAlign: 'right' }]}>{En.serialNumber}</Label>
                </View>

                {loading ? <ActivityIndicator size={35} color={COLOR.red} style={{ marginTop: hp(2) }} />
                    :
                    renderData?.map((item, index) => (
                        <ConsultationView
                            item={item}
                            key={index}
                            number={getSerialNumber(index)}
                            firstHeading={En.viewDetails}
                            secondHeading={En.delete}
                            onFirstPress={() => onViewDetailPress(item)}
                            onSecondPress={() => handleDeleteItem(item?.documentId)}
                        />
                    ))}

            </ScrollView>

            <ListFooter
                note={noteString}
                showPreviousButton={showPreviousButton}
                moveToNextPage={moveToNextPage}
                moveToPreviousPage={moveToPreviousPage}
                currentPage={currentPage}
                showNextButton={showNextButton}
            />

        </Layout>
    )
}

export default RequestScreen

const styles = StyleSheet.create({
    inputContainer: {
        width: wp('10%'),
        borderRadius: hp(1),
        marginHorizontal: '1%',
        height: hp(5.7),
    },
    headerStyle: {
        ...commonStyles.horizontalView_m1,
        paddingHorizontal: '5%',
    },
    buttonStyle: {
        width: wp(18),
        ...commonStyles.center,
        height: hp(5)
    },
    headerText: {
        minWidth: '7%',
        fontWeight: '700',
        textAlign: 'center',
    },
    container: {
        height: hp(6),
        width: '90%',
        marginHorizontal: '5%',
        backgroundColor: COLOR.secondary,
        borderRadius: hp(4),
        paddingHorizontal: '3%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        marginTop: '0.5%',
        alignItems: 'center',
        marginVertical: '1%',
    },
    arrowButtons: {
        height: hp(5),
        width: hp(5),
        borderRadius: hp(3),
        backgroundColor: COLOR.secondary,
        ...commonStyles.center,
    },
    arrowStyle: {
        height: '50%',
        width: '90%',
    },
    buttonContainer: {
        ...commonStyles.horizontalView,
        marginBottom: hp(3),
        marginLeft: '5%',
    },
})