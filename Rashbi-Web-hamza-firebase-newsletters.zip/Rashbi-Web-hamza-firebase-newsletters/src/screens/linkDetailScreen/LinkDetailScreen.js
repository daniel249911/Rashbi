import { ActivityIndicator, ScrollView, StyleSheet, View } from 'react-native'
import React, { useState, useEffect } from 'react'
import { Button, CategoriesView, Label, Layout } from '../../components'
import En from '../../data/locals/En'
import { hp, commonStyles, wp, COLOR } from '../../data/StyleGuides'
import { IMAGES } from '../../assets/images'
import { FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import { deleteDocument, getCollectionData } from '../../services/firebaseServices'
import { useIsFocused } from '@react-navigation/native'

const LinkDetailScreen = ({ navigation }) => {
    const [links, setLinks] = useState([])
    const [loading, setLoading] = useState(false)
    const isFocused = useIsFocused()

    useEffect(() => {
        getLinksData()
    }, [isFocused])

    const getLinksData = async () => {
        setLoading(true)
        const data = await getCollectionData(FIREBASE_COLLECTION.SOCIAL_LINKS)
        if (data) {
            setLinks(data)
        }
        setLoading(false)
    }

    const handleDeleteItem = (id) => {
        deleteDocument(FIREBASE_COLLECTION.SOCIAL_LINKS, id)
        getLinksData()
    }

    return (
        <Layout title={En.links}>

            <View style={styles.headerStyle}>

                <Button
                    style={styles.buttonStyle} text={En.addNewLink}
                    icon={IMAGES.AddIcon}
                    onPress={() => navigation.navigate(SCREEN.ADD_LINK)}
                />

            </View>


            <ScrollView
                bounces={false}
                overScrollMode='never'
                showsVerticalScrollIndicator={false}
            >
                <View style={styles.container}>
                    <Label style={{ fontWeight: '700' }}>{En.operations}</Label>
                    <Label style={{ fontWeight: '700' }}>{En.links}</Label>
                    <Label style={{ fontWeight: '700' }}>.{En.serialNumber}</Label>
                </View>
                {loading ? <ActivityIndicator size={35} color={COLOR.red} style={{ marginTop: hp(2) }} />
                    :
                    <View style={styles.categorView}>
                        {links?.map((item, index) => (
                            <CategoriesView
                                text={item?.url}
                                key={index}
                                number={index + 1}
                                firstHeading={En.edit}
                                secondHeading={En.delete}
                                onSecondPress={() => handleDeleteItem(item?.documentId)}
                                onFirstPress={() => navigation.navigate(SCREEN.ADD_LINK, { isEdit: true, data: item })}
                            />
                        ))}
                    </View>
                }


            </ScrollView>



        </Layout>
    )
}

export default LinkDetailScreen

const styles = StyleSheet.create({
    inputContainer: {
        width: wp('10%'),
        // backgroundColor: 'blue',
        borderRadius: hp(1),
        marginHorizontal: '1%',
        height: hp(5.7),
    },
    headerStyle: {
        ...commonStyles.justifyView,
        paddingHorizontal: '5%',
    },
    buttonStyle: {
        width: wp(18),
        ...commonStyles.center,
        height: hp(5)
    },
    container: {
        height: hp(6),
        width: '90%',
        marginHorizontal: '5%',
        backgroundColor: COLOR.secondary,
        borderRadius: hp(4),
        paddingHorizontal: '3%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        marginTop: '0.5%',
        alignItems: 'center',
        marginVertical: '1%',
    },
    arrowButtons: {
        height: hp(5),
        width: hp(5),
        borderRadius: hp(3),
        backgroundColor: COLOR.secondary,
        ...commonStyles.center,
    },
    arrowStyle: {
        height: '50%',
        width: '90%',
    },
    buttonContainer: {
        ...commonStyles.horizontalView,
        marginBottom: hp(3),
        marginLeft: '5%',
    },
})