import HomeSliderScreen from './HomeSliderScreen'
export default HomeSliderScreen