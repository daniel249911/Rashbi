import React, { useState, useEffect } from 'react'
import { Image, StyleSheet, View, ScrollView } from 'react-native'
import { IMAGES } from '../../assets/images'
import { Button, Label, Layout, ImagePicker, SliderImage } from '../../components'
import { COLOR, commonStyles, hp, wp } from '../../data/StyleGuides'
import En from '../../data/locals/En'
import { getDocumentById, saveData, uploadImage } from '../../services/firebaseServices'
import { FIREBASE_STORAGE, FIREBASE_COLLECTION, FIREBASE_DOCUMENT } from '../../data/enums'
import { useIsFocused } from '@react-navigation/native'

const HomeSliderScreen = () => {
  const [selectedImage, setSelectedImage] = useState('')
  const [images, setImages] = useState([])
  const [loading, setLoading] = useState(false)
  const isFocused = useIsFocused()

  useEffect(() => {
    getSliderData()
  }, [isFocused])

  const getSliderData = async () => {
    const data = await getDocumentById(FIREBASE_COLLECTION.APP_CONFIG, FIREBASE_DOCUMENT.HOME_SLIDER)
    if (data) {
      setImages(data?.images)
    }
  }

  const handleAddImage = (x) => {
    const updatedArray = [...images, x]
    setImages(updatedArray)
  }

  const removeImage = (index) => {
    if (images.length == 1) {
      setSelectedImage('')
    }
    const newArray = images.filter((x, i) => index !== i)
    setImages(newArray)
  }

  const handleSaveData = async () => {
    if (images.length >= 1) {
      setLoading(true)

      let uploadedImages = []

      for (const item of images) {
        let imageUrl = item

        if (!imageUrl?.includes('https:') && !imageUrl?.includes('http:')) {
          imageUrl = await uploadImage(item, FIREBASE_STORAGE.SLIDER)
          if (imageUrl === 'false') {
            alert(En.somethingWentWrong)
            return
          }
        }
        uploadedImages?.push(imageUrl)
      }

      const formattedData = {
        images: uploadedImages,
      }

      await saveData(FIREBASE_COLLECTION.APP_CONFIG, FIREBASE_DOCUMENT.HOME_SLIDER, formattedData)
      setLoading(false)
      getSliderData()
    }
  }

  return (
    <Layout title={En.homeSlider}>
      <ScrollView
        bounces={false}
        overScrollMode='never'
        showsVerticalScrollIndicator={false}
      >

        <View style={styles.mainView}>
          <Label style={{ fontWeight: '700' }}>{En.imageSlider}</Label>

          {/* <View style={{ flexDirection: 'row', marginRight: wp(35) }}>
            <Input style={styles.inputContainer} />
            <Label style={{ fontWeight: '700', marginTop: hp(2) }}>{En.refreshInterval}</Label>
          </View> */}

        </View>

        <Image source={selectedImage} style={styles.imageContainer} />

        <Label style={{ fontWeight: '700', paddingHorizontal: '2%' }}>{En.uploadPhoto}</Label>
        <View style={styles.imageView}>

          {images?.map((item, index) => (
            <SliderImage
              image={item}
              onPress={() => setSelectedImage(item)}
              onRemovePress={() => removeImage(index)}
            />
          ))}

          <ImagePicker
            value={IMAGES.SliderAdd}
            onChange={handleAddImage}
            text={En.uploadImage}
            style={styles.sliderView}
          />

        </View>

        <Button
          text={En.done}
          style={styles.buttonStyle}
          icon={IMAGES.TrueIcon}
          isLoading={loading}
          onPress={handleSaveData}
        />

      </ScrollView>

    </Layout>
  )
}

export default HomeSliderScreen

const styles = StyleSheet.create({
  mainView: {
    flexDirection: 'row-reverse',
    marginVertical: hp(4),
    paddingHorizontal: '2%',
  },
  inputContainer: {
    width: wp(18),
    marginHorizontal: hp(1),
  },
  imageContainer: {
    height: hp(33),
    width: wp(24),
    // backgroundColor:'red',
    alignSelf: 'center',
    borderRadius: hp(2), borderWidth: 2, borderColor: COLOR.red
  },
  imageView: {
    flexDirection: 'row',
    justifyContent: 'center',
    // backgroundColor: 'blue',
    marginTop: hp(2),
  },
  sliderView: {
    height: hp(9),
    width: wp(8),
    borderRadius: hp(2),
  },
  buttonStyle: {
    width: wp(10),
    ...commonStyles.center,
    height: hp(5),
    alignSelf: 'flex-start',
    marginLeft: hp(9),
  },




})